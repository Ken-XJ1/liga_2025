<?php
include("conexion.php");

// Consulta para obtener las vistas de la base de datos
$sql = "SELECT TABLE_NAME 
        FROM INFORMATION_SCHEMA.VIEWS 
        WHERE TABLE_SCHEMA = 'liga_2025'";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Vistas Disponibles</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="contenedor">
        <h2>📊 Vistas Disponibles</h2>
        <ul>
            <?php
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $vista = $row["TABLE_NAME"];
                    echo "<li><a href='ejecutar.php?tipo=vista&nombre=$vista'>$vista</a></li>";
                }
            } else {
                echo "<p>No hay vistas creadas en la base de datos.</p>";
            }
            ?>
        </ul>
        <a href="index.php" class="btn">⬅ Volver al inicio</a>
    </div>
</body>
</html>
