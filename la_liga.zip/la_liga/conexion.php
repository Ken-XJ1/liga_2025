<?php
$servername = "localhost";
$username   = "root";     // por defecto en XAMPP
$password   = "";         // vacío en XAMPP
$database   = "liga_2025";  // tu base de datos real

$conn = new mysqli($servername, $username, $password, $database);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
