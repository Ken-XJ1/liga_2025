<?php
include("conexion.php");

$tipo = $_GET['tipo'] ?? '';
$nombre = $_GET['nombre'] ?? '';

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ejecutar</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="contenedor">
        <h2>Resultado de <?= htmlspecialchars($nombre) ?></h2>
        <table border="1">
            <tr>
                <?php
                if ($tipo == "vista") {
                    $sql = "SELECT * FROM $nombre";
                } elseif ($tipo == "proc") {
                    $sql = "CALL $nombre()";
                } else {
                    die("Tipo inválido");
                }

                if ($result = $conn->query($sql)) {
                    // Cabeceras
                    $fields = $result->fetch_fields();
                    foreach ($fields as $field) {
                        echo "<th>" . $field->name . "</th>";
                    }
                    echo "</tr>";

                    // Filas
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        foreach ($row as $value) {
                            echo "<td>" . htmlspecialchars($value) . "</td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='100%'>Error al ejecutar: " . $conn->error . "</td></tr>";
                }
                ?>
        </table>
        <a href="index.php" class="btn">⬅ Volver al inicio</a>
    </div>
</body>
</html>
