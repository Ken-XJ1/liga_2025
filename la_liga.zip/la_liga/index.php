<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>La Liga - Inicio</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="container">
        <h1>Bienvenido al sistema de La Liga</h1>
        <p>Selecciona una opción:</p>
        <div class="menu">
            <a href="vistas.php">📊 Ver Vistas</a>
            <a href="procedimientos.php">⚙️ Ver Procedimientos</a>
        </div>
    </div>
</body>
</html>
