<?php
include("conexion.php");

// Consulta para obtener los procedimientos
$sql = "SELECT ROUTINE_NAME 
        FROM INFORMATION_SCHEMA.ROUTINES 
        WHERE ROUTINE_SCHEMA = 'liga_2025' AND ROUTINE_TYPE = 'PROCEDURE'";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Procedimientos Almacenados</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="contenedor">
        <h2>⚙ Procedimientos Almacenados</h2>
        <ul>
            <?php
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $proc = $row["ROUTINE_NAME"];
                    echo "<li><a href='ejecutar.php?tipo=proc&nombre=$proc'>$proc</a></li>";
                }
            } else {
                echo "<p>No hay procedimientos creados en la base de datos.</p>";
            }
            ?>
        </ul>
        <a href="index.php" class="btn">⬅ Volver al inicio</a>
    </div>
</body>
</html>
